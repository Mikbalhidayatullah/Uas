from flask_wtf import FlaskForm
from flask_login import current_user
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError 
from vege.models import Member


class Registrasi_F(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    fullname = StringField('Full Name', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')
    #tambahkan cek username & password sama
    def validate_username(self, username):
        member = Member.query.filter_by(username=username.data). first()
        if member:
            raise ValidationError('Usename yang anda masukan sudah digunakan, cobalah menggunakan username yang berbeda')
    
    def validate_email(self, email):
        member = Member.query.filter_by(email=email.data). first()
        if member:
            raise ValidationError('Email yang anda masukan sudah digunakan, cobalah menggunakan email yang berbeda')
    
class Login_F(FlaskForm):
   
    email = StringField('Email', validators=[DataRequired(), Email()])
    password=PasswordField('Password', validators=[DataRequired()])
    remember= BooleanField('Remember Me')
    submit=SubmitField('Login')


class RequestReset_F(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    submit = SubmitField('Request Password Reset')
    
    def validate_email(self, email):
        user = Member.query.filter_by(email=email.data). first()
        if user is None:
            raise ValidationError('Maaf Email anda belum terdaftar, silahkan lakukan registrasi')

class ResetPassword_F(FlaskForm):
    password=PasswordField('Password', validators=[DataRequired()])
    konfirmasi_password=PasswordField('Konfirmasi Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Reset Password')




