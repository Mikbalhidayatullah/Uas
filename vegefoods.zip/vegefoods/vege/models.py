from datetime import datetime
from vege import db,login_manager, app
from flask_login import UserMixin


@login_manager.user_loader
def load_user(member_id):
    return Member.query.get(int(member_id))

class Member(db.Model, UserMixin): 
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    images = db.Column(db.String(20), nullable=False, default='default.jpg')
    password = db.Column(db.String(60), nullable=False)
    checkout = db.relationship('Checkout', backref='pay', lazy=True)

class Checkout(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    member_id = db.Column (db.Integer, db.ForeignKey('member.id'), nullable=False)
    chart_id = db.Column (db.Integer, db.ForeignKey('chart.id'), nullable=False)

class Chart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    jumlah_chart = db.Column(db.String(5), unique=True, nullable=False)
    total_harga = db.Column(db.String(13), unique=True, nullable=False)
    barang_id = db.Column (db.Integer, db.ForeignKey('barang.id'), nullable=False)
    chart = db.relationship('Checkout', backref='chart', lazy=True)

class Barang(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nm_barang = db.Column(db.String(25), unique=True, nullable=False)
    harga = db.Column(db.String(13), unique=True, nullable=False)
    barang = db.relationship('Chart', backref='barang', lazy=True)
    jb_id = db.Column (db.Integer, db.ForeignKey('jbarang.id'), nullable=False)

class Jbarang(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nm_jbarang = db.Column(db.String(25), unique=True, nullable=False)
    jbarang = db.relationship('Barang', backref='jenis', lazy=True)
