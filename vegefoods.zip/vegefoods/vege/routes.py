from flask import render_template, url_for, flash, redirect
from vege import app, bcrypt, db
from vege.forms import Registrasi_F, Login_F
from vege.models import Member, Checkout, Chart, Barang, Jbarang
from flask_login import login_user, current_user, logout_user


@app.route("/")
@app.route("/home")
def home():
    return render_template("index.html", title='Home')

@app.route("/about")
def about():
    return render_template("about.html", title='About')

@app.route("/contact")
def contact():
    return render_template("contact.html", title='Contact')

@app.route("/shop")
def shop():
    return render_template("shop.html", title='Shop')

@app.route("/wishlist")
def wishlist():
    return render_template("wishlist.html", title='Wishlist')

@app.route("/product-single")
def product_single():
    return render_template("product-single.html", title='Product Single')

@app.route("/cart")
def cart():
    return render_template("cart.html", title='Cart')

@app.route("/checkout")
def checkout():
    return render_template("checkout.html", title='Checkout')

@app.route("/blog")
def blog():
    return render_template("blog.html", title='Blog')

@app.route("/blog/single")
def blog_single():
    return render_template("blog-single.html", title='Blog Single')

@app.route("/login", methods=['GET','POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = Login_F()
    if form.validate_on_submit():
        member = Member.query.filter_by(email = form.email.data).first()
        if member and bcrypt.check_password_hash(member.password, form.password.data):
            login_user(member, remember=form.remember.data)
            return redirect('home')
        else:
            flash('Login gagal.!!!, Periksa username dan password','danger')
    return render_template("login.html", form=form)

@app.route("/registrasi", methods=['GET','POST'])
def registrasi():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    form = Registrasi_F()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        member = Member(username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(member)
        db.session.commit()
        flash('Your account was successfully added','success')
        return redirect(url_for('login'))
    return render_template("registrasi.html", form=form)

@app.route("/logout")
def logout():
    login_user()
    return redirect(url_for('home'))